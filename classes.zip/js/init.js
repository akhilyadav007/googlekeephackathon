(function ($) {
    $(function () {

        // Initialize collapse button
        $(".button-collapse").sideNav();
         $('select').material_select();
         $('.modal-trigger').leanModal();  //init modal after scopes are loaded

    }); // end of document ready
})(jQuery); // end of jQuery name space